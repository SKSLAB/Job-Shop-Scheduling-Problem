clc; clear

Probno = 12;
%% Data
[nbMachines,nbJobs,duration,release,due,cost,Nm,Conflict] = ProblemData(Probno);
[A,b,Aeq,beq,lb,ub,D,f] = JSSP(nbMachines,nbJobs,duration,release,due,cost,Nm,Conflict);

[X,FVAL,EXITFLAG,OUTPUT] = intlinprog(f,1:D-nbJobs,A,b,Aeq,beq,lb,ub);