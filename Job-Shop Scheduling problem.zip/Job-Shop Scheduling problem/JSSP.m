function [A,b,Aeq,beq,lb,ub,D,f] = JSSP(nbMachines,nbJobs,duration,release,due,cost,Nm,Z)


%% Dimensions
nx = nbJobs*nbMachines; % number of x variables
ny = nbJobs*nbJobs; % number of y variables
nts = nbJobs; % number of ts
D = nx+ny+nts; % dimension of the problems

%% Bounds of the porblem
lb = [zeros(1,nx),zeros(1,ny),release];
ub = [ones(1,nx),ones(1,ny),due];

%% Objective function vector
f = [reshape(cost',1,nx) zeros(1,ny) zeros(1,nts)]; % Eqn 15

%% Inequality constraints
A1 = [zeros(nts,nx) zeros(nts,ny) -eye(nts)]; %Eqn 16 (nbJob equations)
b1 = -release(:); % RHS
%---------------------------------------------------------------------%
A2 = zeros(nbJobs,D); % Eqn 17 (nbJob equations)
for i = 1:nbJobs
    A2(i, 1+nbMachines*(i-1):i*nbMachines) =  duration(i,:); % x coefficients
    A2(i,nx+ny+i) = 1; % ts coefficients
end
b2 = due(:); % RHS
%---------------------------------------------------------------------%
A3 = [];b3 = [];
A3 = zeros(nbMachines,D); % Eqn 19 (nbMachines equations)
for m = 1:nbMachines
    A3(m,m:nbMachines:nx) = duration(:,m); % x coefficients
end
b3 = (max(due) - min(release))*ones(nbMachines,1);
%---------------------------------------------------------------------%
nEqn20 = nbMachines*(nbJobs*(nbJobs-1)/2); % Equation 20
A4 = zeros(nEqn20,D);
k = 0; % Counter for equation number
for m = 1:nbMachines
    for i = 1:nbJobs
        for j = i+1:nbJobs
            k = k+1;
            A4(k,(i-1)*nbMachines+m) = 1; % coefficients of xim
            A4(k,(j-1)*nbMachines+m) = 1; % coefficients of xi'm
            A4(k,nx+(i-1)*nbJobs+j) = -1; % coefficients of yii'
            A4(k,nx+(j-1)*nbJobs+i) = -1; % coefficients of yi'i
        end
    end
end
b4 = ones(nEqn20,1);
%---------------------------------------------------------------------%
nEqn21 = (nbJobs-1)*nbJobs; % Equation 21
A5 = zeros(nEqn21,D);
k = 0;
u = sum(max(duration,[],2));
for i = 1:nbJobs
    for j = [1:i-1 i+1:nbJobs]
        k = k+1;
        A5(k, 1+nbMachines*(i-1):i*nbMachines) =  duration(i,:); % coefficients of x
        A5(k,nx+j+(i-1)*nbJobs) = u; % coefficients of y
        A5(k,nx+ny+i) = 1; % coefficients of tsi
        A5(k,nx+ny+j) = -1; % coefficients of tsi';
    end
end
b5 = u*ones(nEqn21,1);
%---------------------------------------------------------------------%
nEqn22 = (nbJobs*(nbJobs-1)/2); % Equation 22
A6 = zeros(nEqn22,D);
k = 0;
for i = 1:nbJobs
    for j = i+1:nbJobs
        k = k+1;
        A6(k,nx+(i-1)*nbJobs+j) = 1; % coefficients of yii'
        A6(k,nx+(j-1)*nbJobs+i) = 1; % coefficients of yi'i
    end
end
b6 = ones(nEqn22,1);
%---------------------------------------------------------------------%
nEqn23 = nbMachines*(nbMachines-1)*nbJobs*(nbJobs-1)/2; % Equation 23
A7 = zeros(nEqn23,D);
k = 0;
for i = 1:nbJobs
    for j = i+1:nbJobs
        for m = 1:nbMachines
            for n = [1:m-1 m+1:nbMachines]
                k = k+1;
                A7(k,nx+(i-1)*nbJobs+j) = 1; % coefficients of yii'
                A7(k,nx+(j-1)*nbJobs+i) = 1; % coefficients of yi'i
                A7(k,(i-1)*nbMachines+m) = 1;% coefficients of xim
                A7(k,(j-1)*nbMachines+n) = 1;% coefficients of xi'm'
            end
        end
    end
end
b7 = 2*ones(nEqn23,1);

A8 = []; b8 = [];
nEqnConflict1 = nx;
A8 = zeros(nEqnConflict1,D);
A8(1:nx,1:nx) = eye(nx);
b8 = ones(nEqnConflict1,1).*(1-reshape(Z',1,nx))';
%---------------------------------------------------------------------%

A9 = zeros(nbMachines,D);
b9 = Nm(:);
for i = 1:nbMachines
    A9(i,i:nbMachines:nbMachines*nbJobs) = 1;
end

%---------------------------------------------------------------------%
A = [A1;A2;A3;A4;A5;A6;A7;A8;A9];
b = [b1;b2;b3;b4;b5;b6;b7;b8;b9];

%---------------------------------------------------------------------%
%% Equality constraints
Aeq = zeros(nbJobs,D); % Equation 18
for i = 1:nbJobs
    Aeq(i,(i-1)*nbMachines+1:i*nbMachines) = 1;
end
beq = ones(nbJobs,1);


